#ifndef MERGE_SORT_H_
#define MERGE_SORT_H_

#include <iostream>
#include <random> //random_device, mt199937, uniform_int_distribution
#include <algorithm> //std::swap
#include <time.h> //clock_t, clock(), CLOCKS_PER_SEC

template <class Itemtype>
class Merge_Sort
{
    public:
        Merge_Sort(int sizeVal);
        virtual ~Merge_Sort();
        void serialize() const;
        void sort(int front, int end);
        void merge(int start, int mid, int end);
        void deallocate();

    private:
        Itemtype *arr;
        int size;
        float seconds = 0;
        int clicks = 0;
        size_t comparisons = 0;
        size_t swaps = 0;
};

template <class Itemtype>
Merge_Sort<Itemtype>::Merge_Sort(int sizeVal)
{
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, 1000000);

    arr = new (std::nothrow) int [sizeVal];
    size = sizeVal;

    for(int i = 0; i < size; i++)
    {
        arr[i] = dis(gen);
    }

}

template <class Itemtype>
Merge_Sort<Itemtype>::~Merge_Sort()
{
    deallocate();
}

template <class Itemtype>
void Merge_Sort<Itemtype>::deallocate()
{
    delete[] arr;
    arr = nullptr;
}

template <class Itemtype>
void Merge_Sort<Itemtype>::serialize() const
{

    for(int i = 0; i < size; i++)
    {
        if(i % 10 == 0){
            std::cout << std::endl;
            std::cout << arr[i] << ", ";
        }
    }

    std::cout << std::endl << "The sorting took "
        << clicks << " clicks and "
        << seconds << " seconds." << std::endl;

    std::cout << "There were "
        << comparisons << " comparisons and "
        << swaps << " swaps." << std::endl;
}

template <class Itemtype>
void Merge_Sort<Itemtype>::merge(int start, int mid, int end)
{
    int start2 = mid + 1;
    clock_t t;

    t = clock();
    // If the direct merge is already sorted
    if (arr[mid] <= arr[start2])
    {
        comparisons++;
        t = clock() - t;
        clicks += t;
        return;
    }

    // Two pointers to maintain start
    // of both arrays to merge
    while (start <= mid && start2 <= end)
    {
        comparisons++;
        // If element 1 is in right place
        if (arr[start] <= arr[start2])
        {
            comparisons++;
            start++;

        }
        else
        {
            int value = arr[start2];
            int index = start2;

            // Shift all the elements between element 1
            // element 2, right by 1.
            while (index != start)
            {
                comparisons++;
                arr[index] = arr[index - 1];
                swaps++;
                index--;
            }
            arr[start] = value;
            swaps++;

            // Update all the pointers
            start++;
            mid++;
            start2++;
        }
    }
} // end merge


template <class Itemtype>
void Merge_Sort<Itemtype>::sort(int front, int end)
{
    clock_t t;
    t = clock();

    if (front < end){
        comparisons++;
        int mid = front + (end - front) / 2;
        sort(front, mid);
        sort(mid + 1, end);
        merge(front, mid, end);
    }
    t = clock() - t;

    clicks += t;
    seconds = ((float(clicks)/CLOCKS_PER_SEC));
}


#endif