#ifndef BUBBLE_SORT_H_
#define BUBBLE_SORT_H_


#include <iostream>
#include <random>
#include <algorithm>
#include <time.h>

template<typename ItemType>
class Bubble_Sort
{
    public:
        Bubble_Sort(int sizeVal);
        virtual ~Bubble_Sort();
        void serialize() const;
        void sort();
        
    private:
        ItemType *array;
        int size;
        float seconds = 0;
        int clicks = 0;
        size_t comparisons = 0;
        size_t swaps = 0;
        
};

/**Prameterized Constructor for Bubble Sort, filling dynamic array 
 * with random val & parameterizing size of array
 */
template<class ItemType>
Bubble_Sort<ItemType>::Bubble_Sort(int sizeVal)
{
    //initiallizing random units
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, 1000000);
    
    //resizing vector & setting size
    array = new(std::nothrow) ItemType [sizeVal];
    size = sizeVal;
    
    //filling vector with random val
    for(int i = 0; i < size; i++){
        array[i] = dis(gen);
    }
}

//Destructor for Bubble Sort
template<class ItemType>
Bubble_Sort<ItemType>::~Bubble_Sort()
{
    //deallocating the dynamic array
    delete[] array;
    array = nullptr;
}

//Method to print values of array, also prints time, comparison and swaps
template<class ItemType>
void Bubble_Sort<ItemType>::serialize() const
{
    for(int i = 0; i < size; i++){
        if(i % 10 == 0){
            std::cout << std::endl;
            std::cout << array[i] << ", ";
        }
    }
    
    std::cout << std::endl << "The sorting took " << clicks << " clicks and "
         << seconds << " seconds." << std::endl;
         
    std::cout << "There were " << comparisons << " comparisons and "
         << swaps << " swaps." << std::endl;
}

/**
 * Method for sorting, almost the same as lecture slides with some minor changes
 * added changes gor comparisons and swap increments, & added time keeping
 */
template<class ItemType>
void Bubble_Sort<ItemType>::sort()
{
    bool swapped = false;
    clock_t t;
    t = clock();
    
    for(int i = 0; i < size; i++){
        swapped = false;
        for(int j = 0; j < size - 1; j++){
            if(array[j] > array[j + 1]){
                comparisons ++;
                std::swap(array[j], array[j + 1]);
                swaps++;
                swapped = true;
            }
        }
        if(!swapped){
            break;
        }
    }
    
    t = clock() - t;
    clicks = t;
    seconds = ((float(t)/CLOCKS_PER_SEC));
}

#endif