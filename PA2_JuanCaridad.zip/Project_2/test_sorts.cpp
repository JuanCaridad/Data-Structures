#include "Bubble_Sort.h"
#include "Merge_Sort.h"

using namespace std;

int main()
{
    int Sort_Option = 0, Val_Option = 0;
    bool menu = true;
    
    while(menu){
        cout << endl << "Which sort method would you like to test?" << endl
             << "1. Bubble_Sort" << endl
             << "2. Merge_Sort" << endl
             << "3. Quit Program" << endl;
        cin >> Sort_Option;
        
        switch(Sort_Option){
            case 1:
                cout << "-----BUBBLE_SORT-----" << endl
                     << "1. Thousand" << endl
                     << "2. Ten Thousand" << endl
                     << "3. Hundred Thousand" << endl;
                cin >> Val_Option;
                    
                    switch(Val_Option){
                        case 1 :
                            {
                            cout << "-----Testing Thousand Values-----" << endl;
                            Bubble_Sort<int> Bthousand(1000);
                            Bthousand.sort();
                            Bthousand.serialize();
                            Bthousand.~Bubble_Sort();
                            }   
                            break;
                        case 2 :
                            {
                            cout << "-----Testing Ten Thousand Values-----" << endl;
                            Bubble_Sort<int> BTenThousand(10000);
                            BTenThousand.sort();
                            BTenThousand.serialize();
                            BTenThousand.~Bubble_Sort();
                            }
                            break;
                        case 3 :
                            {
                            cout << "-----Testing Hundred Thousand Values-----" << endl;
                            Bubble_Sort<int> BHundredThousand(100000);
                            BHundredThousand.sort();
                            BHundredThousand.serialize();
                            BHundredThousand.~Bubble_Sort();
                            }
                            break;
                        default :
                            cout << "Invalid Option" << endl;
                            break;
                    }
                break;
            
            case 2:
                cout << "-----MERGE_SORT-----" << endl
                     << "1. Thousand" << endl
                     << "2. Ten Thousand" << endl
                     << "3. Hundred Thousand" << endl;
                cin >> Val_Option;
                
                    switch(Val_Option){
                        case 1 : 
                            {
                            cout << "-----Testing Thousand Values" << endl;
                            Merge_Sort<int> MThousand(1000);
                            MThousand.sort(0, 1000);
                            MThousand.serialize();
                            MThousand.~Merge_Sort();
                            }
                            break;
                        case 2 : 
                            {
                            cout << "-----Testing Ten Thousand Values" << endl;
                            Merge_Sort<int> MTenThousand(10000);
                            MTenThousand.sort(0, 10000);
                            MTenThousand.serialize();
                            MTenThousand.~Merge_Sort();
                            }
                            break;
                        case 3 :
                            {
                            cout << "-----Testing Hundred Thousand Values" << endl;
                            Merge_Sort<int> MHundredThousand(100000);
                            MHundredThousand.sort(0, 100000);
                            MHundredThousand.serialize();
                            MHundredThousand.~Merge_Sort();
                            }
                            break;
                        default : 
                            cout << "Invalid Option" << endl;
                            break;
                    }
                break;
            
            case 3 :
                menu = false;
                break;
            
            default : 
                cout << "Invalid Option" << endl;
                break;
        }
    }
    
return 0;

}