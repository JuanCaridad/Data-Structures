#include <iostream>
#include <vector> 
#include <stdlib.h> 
#include "LeftLeaningRedBlack.h"

void Perform(void);
using namespace std;

int main()
{
    Perform();

    return 0;
}

//Function to test left leaning red black tree
void Perform(void)
{
    int limit = 10;
    int *Keys = new int[limit];
    srand(123456);

    for (int i = 0; i < limit; ++i)
    {
        Keys[i] = rand() % 100;
    }

    LeftLeaningRedBlack sort4;

    int helper;
	VoidRef_t ref;
	ref.pContext = &helper;

	sort4.FreeAll();

	cout << endl << "Inserts" << "\t"
        "| Parent at Insertion" << std::endl << std::endl;

    for (int i = 0; i < limit; ++i)
    {
        ref.Key = Keys[i];
        sort4.Insert(ref);
        sort4.printNode(Keys[i]);

        cout << "\t";

        sort4.printParent(ref.Key);
        cout << endl;

    }

    //prints entire tree
    cout << endl << "Traversal After Insertion"
        << endl << "====================" << endl;

    sort4.Traverse();

    //removes 4th element and reprints tree
    cout << endl << "Removal of 4th Element Inserted"
    << endl << "===================-" << endl;

    sort4.Delete(Keys[3]);

    sort4.Traverse();

    for (int i = 0; i < limit; ++i)
    {
        sort4.Delete(Keys[i]);
    }

    sort4.FreeAll();
    delete[] Keys;

}