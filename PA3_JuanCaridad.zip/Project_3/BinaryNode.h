#ifndef BINARY_NODE_
#define BINARY_NODE_

#include<memory>

template<class ItemType>
class BinaryNode
{
    private:
        ItemType item;
        std::shared_ptr<BinaryNode<ItemType>> leftChildPtr;
        std::shared_ptr<BinaryNode<ItemType>> rightChildPtr;

    public:
        BinaryNode();
        BinaryNode(const ItemType & itemT);
        BinaryNode(const ItemType & other, std::shared_ptr<BinaryNode<ItemType>> leftPtr,
                    std::shared_ptr<BinaryNode<ItemType>> rightPtr);
        
        void setItem(const ItemType & itemT);
        ItemType getItem() const;
        
        void setLeftChildPtr(std::shared_ptr<BinaryNode<ItemType>> leftPtr);
        auto getLeftChildPtr();
        void setRightChildPtr(std::shared_ptr<BinaryNode<ItemType>> rightPtr);
        auto getRightChildPtr();

};

template<class ItemType>
BinaryNode<ItemType>::BinaryNode() : leftChildPtr(nullptr), rightChildPtr(nullptr)
{
}

template<class ItemType>
BinaryNode<ItemType>::BinaryNode(const ItemType & itemT) : item(itemT), leftChildPtr(nullptr), rightChildPtr(nullptr)
{
}

template<class ItemType>
BinaryNode<ItemType>::BinaryNode(const ItemType & other, std::shared_ptr<BinaryNode<ItemType>> leftPtr,
                                    std::shared_ptr<BinaryNode<ItemType>> rightPtr) : item(other), 
                                                                                      leftChildPtr(leftPtr),
                                                                                      rightChildPtr(rightPtr)
{
}

template<class ItemType>
void BinaryNode<ItemType>::setItem(const ItemType & itemT)
{
    item = itemT;
}

template<class ItemType>
ItemType BinaryNode<ItemType>::getItem() const
{
    return item;
}

template<class ItemType>
void BinaryNode<ItemType>::setLeftChildPtr(std::shared_ptr<BinaryNode<ItemType>> leftPtr)
{
    leftChildPtr = leftPtr;
}

template<class ItemType>
auto BinaryNode<ItemType>::getLeftChildPtr()
{
    return leftChildPtr;
}

template<class ItemType>
void BinaryNode<ItemType>::setRightChildPtr(std::shared_ptr<BinaryNode<ItemType>> rightPtr)
{
    rightChildPtr = rightPtr;
}

template<class ItemType>
auto BinaryNode<ItemType>::getRightChildPtr()
{
    return rightChildPtr;
}

#endif