#include <iostream>
#include <random>
#include <vector>
#include <algorithm>
#include <chrono>
#include "BinarySearchTree.h"

void fillBST(BinarySearchTree<int> & bst);

int main()
{
    BinarySearchTree<int> Bst;
    
    fillBST(Bst);
    std::cout << "-----Height-----" << std::endl << Bst.getHeight() << std::endl;
    
    Bst.preorderTraverse();
    Bst.postorderTraverse();
    Bst.inorderTraverse();
    std::cout << "\n";
    
    
return 0;

}

void fillBST(BinarySearchTree<int> & bst)
{
    std::vector<int> rd;
    unsigned leafs = std::chrono::system_clock::now().time_since_epoch().count();
    
    for(int i = 0; i < 200; i++){
        rd.push_back(i);
    }
    
    std::shuffle(rd.begin(), rd.end(), std::default_random_engine(leafs));
    for(int i = 0; i < 100; i++){
        bst.add(rd[i]);
    }
}