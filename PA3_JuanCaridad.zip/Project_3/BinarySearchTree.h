#ifndef BINARY_SEARCH_TREE_
#define BINARY_SEARCH_TREE_

#include <iostream>
#include <memory>
#include <stdexcept>
#include <algorithm>
#include "BinaryNode.h"

template<class ItemType>
class BinarySearchTree
{
    private:
        std::shared_ptr<BinaryNode<ItemType>> rootPtr;
        
    protected:
        std::shared_ptr<BinaryNode<ItemType>>placeNode(std::shared_ptr<BinaryNode<ItemType>> subTreePtr,
                                                        std::shared_ptr<BinaryNode<ItemType>> newNodePtr);
        void PreorderHelp(std::shared_ptr<BinaryNode<ItemType>> subTreePtr) const;
        void InorderHelp(std::shared_ptr<BinaryNode<ItemType>> subTreePtr) const;
        void PostorderHelp(std::shared_ptr<BinaryNode<ItemType>> subTreePtr) const;
        int HeightHelp(std::shared_ptr<BinaryNode<ItemType>> subTreePtr);
        
    public:
        BinarySearchTree();
        virtual ~BinarySearchTree();
        
        bool isEmpty() const;
        int getHeight();
        
        bool add(const ItemType & newEntry);
        bool remove(const ItemType & target);
        
        void preorderTraverse() const;
        void inorderTraverse() const;
        void postorderTraverse() const;
        
};

template<class ItemType>
bool BinarySearchTree<ItemType>::add(const ItemType & newData)
{
    auto newNodePtr = std::make_shared<BinaryNode<ItemType>> (newData);
    rootPtr = placeNode(rootPtr, newNodePtr);
    return true;
}

template<class ItemType> 
std::shared_ptr<BinaryNode<ItemType>>BinarySearchTree<ItemType>::
                                    placeNode(std::shared_ptr<BinaryNode<ItemType>> subTreePtr,
                                            std::shared_ptr<BinaryNode<ItemType>> newNodePtr)
{
    std::shared_ptr<BinaryNode<ItemType>> tempPtr;
    
    if(subTreePtr == nullptr){
        return newNodePtr;
    }
    else if(subTreePtr->getItem() > newNodePtr->getItem()){
        tempPtr = placeNode(subTreePtr->getLeftChildPtr(), newNodePtr);
        subTreePtr->setLeftChildPtr(tempPtr);
    }
    else{
        tempPtr = placeNode(subTreePtr->getRightChildPtr(), newNodePtr);
        subTreePtr->setRightChildPtr(tempPtr);
    }
    
    return subTreePtr;
}

template<class ItemType>
BinarySearchTree<ItemType>::BinarySearchTree() : rootPtr(nullptr)
{
}

template<class ItemType>
BinarySearchTree<ItemType>::~BinarySearchTree()
{
}

template<class ItemType>
bool BinarySearchTree<ItemType>::isEmpty() const
{
    return rootPtr == nullptr;
}

template<class ItemType>
int BinarySearchTree<ItemType>::getHeight()
{
    return HeightHelp(rootPtr);
}

template<class ItemType>
void BinarySearchTree<ItemType>::preorderTraverse() const
{
    std::cout << std::endl << "-----Preorder-----" << std::endl;
    PreorderHelp(rootPtr);
}

template<class ItemType>
void BinarySearchTree<ItemType>::inorderTraverse() const
{
    std::cout << std::endl << "-----Inorder-----" << std::endl;
    InorderHelp(rootPtr);
}

template<class ItemType>
void BinarySearchTree<ItemType>::postorderTraverse() const
{
    std::cout << std::endl << "-----Postorder-----" << std::endl;
    PostorderHelp(rootPtr);
}

template<class ItemType>
void BinarySearchTree<ItemType>::PreorderHelp(std::shared_ptr<BinaryNode<ItemType>> subTreePtr) const
{
    
    if(subTreePtr == nullptr){
        return;
    }
    
    std::cout << subTreePtr->getItem() << " ";
    PreorderHelp(subTreePtr->getLeftChildPtr());
    PreorderHelp(subTreePtr->getRightChildPtr());
}

template<class ItemType>
void BinarySearchTree<ItemType>::InorderHelp(std::shared_ptr<BinaryNode<ItemType>> subTreePtr) const
{
    if(subTreePtr == nullptr){
        return;
    }
    
    InorderHelp(subTreePtr->getLeftChildPtr());
    std::cout << subTreePtr->getItem() << " ";
    InorderHelp(subTreePtr->getRightChildPtr());
}

template<class ItemType>
void BinarySearchTree<ItemType>::PostorderHelp(std::shared_ptr<BinaryNode<ItemType>> subTreePtr) const
{
    if(subTreePtr == nullptr){
        return;
    }
    
    PostorderHelp(subTreePtr->getLeftChildPtr());
    PostorderHelp(subTreePtr->getRightChildPtr());
    std::cout << subTreePtr->getItem() << " ";
}

template<class ItemType>
int BinarySearchTree<ItemType>::HeightHelp(std::shared_ptr<BinaryNode<ItemType>> subTreePtr)
{
    if(subTreePtr == nullptr){
        return 0;
    }
    else{
        int leftHeight = HeightHelp(subTreePtr->getLeftChildPtr());
        int rightHeight = HeightHelp(subTreePtr->getRightChildPtr());
         return std::max(leftHeight, rightHeight) + 1;
        }
}

#endif