#include "StackLinked.h"
#include <string>
#include <cctype>
#include <cmath>

float Convert_Postfix(StackLinked<float> & stack, string postfix);
float Calculate_Postfix(float oper1, float oper2, char postfix_oper) throw(logic_error);

int main()
{
    StackLinked<float> stack;
    
    //exercise 1 assignment 1
    cout << "Exercise 1, Assignment 1" << endl;
    cout << " (3+4)*(5/2) or 34+52/* = " << Convert_Postfix(stack, "34+52/*" ) << endl;
    
    //exercise 1 assignment 2
    cout << "Exercise 1, Assignment 2" << endl;
    cout << "1. (1-3)*(7/8) or 13-78/* = " << Convert_Postfix(stack, "13-78/*" ) << endl;
    cout << "2. (2+1)*(8/5) or 21+85/* = " << Convert_Postfix(stack, "21+85/*" ) << endl;
    cout << "3. (3/6)*(3/3) or 36/33/* = " << Convert_Postfix(stack, "36/33/*" ) << endl;
    cout << "4. (2+5)+(6-7) or 25+67-+ = " << Convert_Postfix(stack, "25+67-+" ) << endl;
    cout << "5. (5^9)^(1+2) or 59^12+^ = " << Convert_Postfix(stack, "59^12+^" ) << endl;
    
    return 0;
    
}

float Convert_Postfix(StackLinked<float> & stack, string postfix)       //interpreting and calculating expression
{
    float oper1, oper2, result;
    char postfix_oper;
    stack.clear(); //make sure that the stack is clear for safety
    
    for(size_t i = 0; i < postfix.length(); i++){       //for loop to iterate over string
        if(isdigit(postfix[i])){                        //checks if digit or num
            stack.push(postfix[i] - '0');               //pushes if number, converts to float or int
        }
        else{
            oper1 = stack.pop();
            oper2 = stack.pop();
            postfix_oper = postfix[i];
            
            result = Calculate_Postfix(oper1, oper2, postfix_oper);
            
            stack.push(result);
        }
    }
    
    return stack.pop();
}

float Calculate_Postfix(float oper1, float oper2, char postfix_oper) throw(logic_error)      //calculating expressions once interpreted
{
    switch(postfix_oper)                                    //testing for all cases
    {
        case '+':
            return oper1 + oper2;
            break;
        case '-':
            return oper2 - oper1;
            break;
        case '*':
            return oper1 * oper2;
            break;
        case '/':
            return oper2 / oper1;
            break;
        case '^':
            return pow(oper2, oper1);
            break;
        default:
            throw logic_error("Operation isn't valid");     //throws error if operator isn't one of the above
    }
}