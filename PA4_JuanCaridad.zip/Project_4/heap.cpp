#include <iostream> 
#include <random>
#include <algorithm>
#include <vector>

using namespace std;

void numGen(vector<int> & vector);
void printVector(vector<int> vector);
int findMean(vector<int> & vector);

int main()
{
    //initializing vector
    vector<int> vec;
    //adding random numbers into vector
    numGen(vec);
    
    cout << "Random Generated Vector";
    printVector(vec);
    
    //making vector a heap
    make_heap(vec.begin(), vec.end());
    cout << endl;
    
    //checking if vector became a heap
    if(is_heap(vec.begin(), vec.end())){
        cout << endl << "Vector is now a Heap";
    }
    
    //finding the mean of the vector and printing
    int meanofVec = findMean(vec);
    
    //pushing mean into heap
    vec.push_back(meanofVec);
    push_heap(vec.begin(), vec.end());
    
    cout << endl << "Mean pushed onto Heap" << endl;
    cout << "Mean is " << meanofVec;
    printVector(vec);
    
    //moving max element to the back then deleting
    pop_heap(vec.begin(), vec.end());
    vec.pop_back();
    
    cout << endl << "Deleted max element of Heap";
    printVector(vec);
    
    //sorting the heap in ascending order
    sort_heap(vec.begin(), vec.end());
    cout << endl << "Sorted Heap";
    printVector(vec);
    cout << endl;
    
    return 0;
    
}

//Function to fill the vector with randomly generated values
void numGen(vector<int> & vector)
{
    //initializers for random
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, 400);
    
    //filling vector with random values in the range
    for(int i = 0; i < 100; i++){
        vector.push_back(dis(gen));
    }
}

//Printing the vector
void printVector(vector<int> vector)
{
    cout << endl;
    
    for(unsigned int i = 0; i < vector.size(); i++){
        if(i % 10 == 0){
            cout << endl;
        }
        
        cout << vector[i] << ", ";
    
    }
}

//finds the mean of the vector
int findMean(vector<int> & vector)
{
    int mean = 0;
    
    for(int i = 0; i < vector.size(); i++){
        mean += vector[i];
    }
    
    return mean / vector.size();

    
}